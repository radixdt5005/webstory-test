export default function(preload){
            return preload(()=> import('./pre.638065378913190000.js'),["assets/_plugin-vue_export-helper.638065378913190000.js","assets/webstory.638065378913190000.css","assets/webstory.component.638065378913190000.js"]);
    }