function e(a,o){a({components:{},masterPage:{},payload:{url:"/webstories/test-amp",slots:{},masterPageSlots:{}}})}export{e as default};
