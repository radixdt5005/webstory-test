function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/varanasi",slots:{},masterPageSlots:{}}})}export{e as default};
