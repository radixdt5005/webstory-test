function t(a,e){a({components:{},masterPage:{},payload:{url:"/articles/tiger-reserves",slots:{},masterPageSlots:{}}})}export{t as default};
