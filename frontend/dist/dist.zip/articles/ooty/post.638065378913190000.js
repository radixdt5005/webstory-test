function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/ooty",slots:{},masterPageSlots:{}}})}export{e as default};
