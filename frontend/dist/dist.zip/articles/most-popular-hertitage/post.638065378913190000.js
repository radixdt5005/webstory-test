function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/most-popular-hertitage",slots:{},masterPageSlots:{}}})}export{e as default};
