function t(a,o){a({components:{},masterPage:{},payload:{url:"/articles/dance-forms",slots:{},masterPageSlots:{}}})}export{t as default};
