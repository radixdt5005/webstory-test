function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/adventure-sports",slots:{},masterPageSlots:{}}})}export{e as default};
