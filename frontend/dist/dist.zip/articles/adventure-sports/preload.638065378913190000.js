export default function(preload){
            return preload(()=> import('./pre.638065378913190000.js'),["assets/article.component.638065378913190000.js"]);
    }