function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/mountain-ranges",slots:{},masterPageSlots:{}}})}export{e as default};
