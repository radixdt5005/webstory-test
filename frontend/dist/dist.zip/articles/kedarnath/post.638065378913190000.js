function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/kedarnath",slots:{},masterPageSlots:{}}})}export{e as default};
