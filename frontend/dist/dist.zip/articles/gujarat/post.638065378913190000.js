function e(a,o){a({components:{},masterPage:{},payload:{url:"/articles/gujarat",slots:{},masterPageSlots:{}}})}export{e as default};
