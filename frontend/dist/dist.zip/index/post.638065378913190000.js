function e(a,o){a({components:{},masterPage:{},payload:{url:"/",slots:{},masterPageSlots:{}}})}export{e as default};
