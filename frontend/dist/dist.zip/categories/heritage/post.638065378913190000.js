function t(a,e){a({components:{},masterPage:{},payload:{url:"/categories/heritage",slots:{},masterPageSlots:{}}})}export{t as default};
