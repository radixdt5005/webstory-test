function t(a,e){a({components:{},masterPage:{},payload:{url:"/categories/adventure",slots:{},masterPageSlots:{}}})}export{t as default};
