function e(a,o){a({components:{},masterPage:{},payload:{url:"/categories/spiritual",slots:{},masterPageSlots:{}}})}export{e as default};
