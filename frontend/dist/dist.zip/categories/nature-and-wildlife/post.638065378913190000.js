function t(a,e){a({components:{},masterPage:{},payload:{url:"/categories/nature-and-wildlife",slots:{},masterPageSlots:{}}})}export{t as default};
