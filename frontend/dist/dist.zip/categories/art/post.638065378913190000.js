function e(a,o){a({components:{},masterPage:{},payload:{url:"/categories/art",slots:{},masterPageSlots:{}}})}export{e as default};
