function e(a,o){a({components:{},masterPage:{},payload:{url:"/about-tezjs",slots:{},masterPageSlots:{}}})}export{e as default};
